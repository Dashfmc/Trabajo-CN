import streamlit as st
import pandas as pd
def luis_junto():
    image = "ProyectoFinal/sentim.png"
    st.image(image, use_container_width=True)
    df = pd.read_csv("C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/Instagram.csv")
    df.columns = df.columns.str.strip()
    if 'Comentarios_positivos' in df.columns and 'Comentarios_negativos' in df.columns and 'Total_comentarios' in df.columns:
        com_pos = df["Comentarios_positivos"]
        com_neg = df["Comentarios_negativos"]
        t_com = df["Total_comentarios"]
        sentimiento = (((com_pos - com_neg) / t_com))*100
        sentimiento = sentimiento.mean()
        st.write(f"Porcentaje de la tasa de sentimiento:{sentimiento}%")
    else:
        st.write("One or more required columns are missing.")
    try:
        with open('ProyectoFinal/luis.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
luis_junto()
