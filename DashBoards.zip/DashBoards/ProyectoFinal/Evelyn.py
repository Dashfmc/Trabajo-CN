import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
def Evelyn_junto():
    try:
        df = pd.read_csv("ProyectoFinal/Pagina_Web.csv")
        df = df.dropna(subset=['Tiempo_en_segundos', 'Visitantes_Unicos'])
        facebook_vistas = df['Visitantes_Unicos'].sum()
        total_tiempo = df['Tiempo_en_segundos'].sum()
        if total_tiempo != 0:
            tiempo_usuario = (facebook_vistas / total_tiempo) * 100
            st.write(f"Tiempo en la Pagina Por Usuario: {tiempo_usuario:.2f} Segundos")
        else:
            st.write("No se puede calcular el porcentaje, ya que el tiempo total es 0.")
        try:
            with open('ProyectoFinal/Evelyn.txt', 'r',
                      encoding='utf-8') as archivo:
                contenido = archivo.read()
            st.write(contenido)
        except FileNotFoundError:
            st.write("Archivo Evelyn.txt no encontrado.")
        plt.figure(figsize=(10, 6))
        plt.scatter(df['Tiempo_en_segundos'], df['Visitantes_Unicos'], color='blue', alpha=0.5)
        plt.title('Relación entre Tiempo en Segundos y Visitantes Unicos', fontsize=14)
        plt.xlabel('Tiempo en Segundos', fontsize=12)
        plt.ylabel('Visitantes Unicos', fontsize=12)
        st.pyplot(plt)
    except FileNotFoundError:
        st.write("Archivo Pagina_Web.csv no encontrado.")
    except Exception as e:
        st.write(f"Ocurrió un error: {str(e)}")
    try:
        with open('C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/Evelyn1.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        st.write(contenido)
    except FileNotFoundError:
        st.write("Archivo Evelyn1.txt no encontrado.")
Evelyn_junto()
