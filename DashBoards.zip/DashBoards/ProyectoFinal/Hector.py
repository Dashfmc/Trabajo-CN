import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

def Hector_junto():
    try:
        data = pd.read_csv("ProyectoFinal/hector.csv")
    except FileNotFoundError:
        st.error("El archivo no fue encontrado. Asegúrate de colocarlo en el mismo directorio que este script.")
        return

    columnas_necesarias = ["Periodo_sep", "Periodo_oct", "Periodo_nov", "Seguidores_deseados"]
    if not all(col in data.columns for col in columnas_necesarias):
        st.error(f"Las columnas necesarias {columnas_necesarias} no se encuentran en el archivo.")
        return

    for columna in columnas_necesarias:
        data[columna] = pd.to_numeric(data[columna], errors="coerce").fillna(0)

    meses = ["Septiembre", "Octubre", "Noviembre"]
    totales_mes = [data["Periodo_sep"].sum(), data["Periodo_oct"].sum(), data["Periodo_nov"].sum()]

    st.subheader("Datos de Seguidores")
    st.dataframe(data[["Periodo_sep", "Periodo_oct", "Periodo_nov", "Seguidores_deseados"]])

    st.subheader("Seguidores por Mes")
    fig, ax = plt.subplots()
    ax.bar(meses, totales_mes, color=["lightblue", "lightgreen", "salmon"])
    ax.set_title("Seguidores Actuales por Mes")
    ax.set_xlabel("Meses")
    ax.set_ylabel("Cantidad de Seguidores")
    st.pyplot(fig)
    try:
        with open('ProyectoFinal/Hector.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
Hector_junto()