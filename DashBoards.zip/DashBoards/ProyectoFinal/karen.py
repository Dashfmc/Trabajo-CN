import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
def Karen_junto():
    df = pd.read_csv("ProyectoFinal/Pagina_Web.csv")
    visitantes = df['Visitantes_Unicos'].sum()
    cliqueado = df['WhatsApp_cliqueado'].sum()
    if visitantes != 0:
        conversion = (cliqueado / visitantes) * 100
        st.write(f"Tasa de Conversión: {conversion:.2f} %")
    else:
        st.write("No se puede calcular el porcentaje, ya que el tiempo total es 0.")
    try:
        with open('ProyectoFinal/Karen.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        st.write(contenido)
    except FileNotFoundError:
        st.write("El archivo 'Karen.txt' no se encontró.")
    except Exception as e:
        st.write(f"Ocurrió un error: {e}")
    plt.figure(figsize=(10, 6))
    plt.scatter(df['WhatsApp_cliqueado'], df['Visitantes_Unicos'], color='blue', alpha=0.5)
    plt.title('Relación entre WhatsApp cliqueado y Visitantes Unicos', fontsize=14)
    plt.xlabel('WhatsApp cliqueado', fontsize=12)
    plt.ylabel('Visitantes Unicos', fontsize=12)
    st.pyplot(plt)
    try:
        with open('ProyectoFinal/Karen1.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        st.write(contenido)
    except FileNotFoundError:
        st.write("El archivo 'Karen.txt' no se encontró.")
    except Exception as e:
        st.write(f"Ocurrió un error: {e}")
Karen_junto()
