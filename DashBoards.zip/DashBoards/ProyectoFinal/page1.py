import streamlit as st

from Elizabeth import Elizabeth_junto
from Evelyn import Evelyn_junto
from karen import Karen_junto

st.markdown("<h1 style='text-align: center; color: #FFB6C1;'>Mejora de Conversión Web</h1>", unsafe_allow_html=True)

models = {
    "Tiempo en web (Dwell Time)": Evelyn_junto,
    "Tasa de rebote por fuente:":Elizabeth_junto,
    "Tasa de conversión.": Karen_junto,
}
selected_model = st.selectbox('Elige un Kpis:', list(models.keys()))
result = models[selected_model]()
st.write(result)