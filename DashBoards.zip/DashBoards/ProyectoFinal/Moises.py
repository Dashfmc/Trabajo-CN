import streamlit as st


def moises_junto():
    # Función para calcular el total de un pedido
    def calcular_total_pedido(pedido):
        total = sum([cantidad * precio_unitario for cantidad, precio_unitario in pedido])
        return total

    # Función para calcular el KPI de rotación de nuevos modelos
    def calcular_rotacion_nuevos_modelos(cogs, inventario_promedio):
        if inventario_promedio == 0:
            return 0  # Evitar división por cero
        return cogs / inventario_promedio

    # Datos de los pedidos
    pedido_1 = [
        (3, 130),  # Bolsa negra
        (1, 130),  # Bolsa caqui
        (1, 130),  # Bolsa blanca
        (3, 147.26),  # Mochila negra
        (2, 147.26)  # Mochila azul
    ]

    pedido_2 = [
        (1, 130),  # Bolsa morada
        (2, 130),  # Bolsa caqui
        (2, 130)  # Bolsa blanca
    ]

    pedido_3 = [
        (4, 140)  # Bolsa negra
    ]

    pedido_4 = [
        (3, 121),  # Bolsa negra nuevo modelo
        (2, 121),  # Bolsa caqui nuevo modelo
        (1, 121)  # Bolsa blanca nuevo modelo
    ]

    # Cálculos
    total_pedido_1 = calcular_total_pedido(pedido_1)
    total_pedido_2 = calcular_total_pedido(pedido_2)
    total_pedido_3 = calcular_total_pedido(pedido_3)
    total_pedido_4 = calcular_total_pedido(pedido_4) + 197  # Incluyendo gasto de envío

    # Inventario promedio de pedidos anteriores
    inventario_promedio = (total_pedido_1 + total_pedido_2 + total_pedido_3) / 3

    # KPI de rotación de nuevos modelos
    rotacion_nuevos_modelos = calcular_rotacion_nuevos_modelos(total_pedido_4, inventario_promedio)

    # Resultados con Streamlit
    st.write(f"Total Pedido 1: ${total_pedido_1:.2f}")
    st.write(f"Total Pedido 2: ${total_pedido_2:.2f}")
    st.write(f"Total Pedido 3: ${total_pedido_3:.2f}")
    st.write(f"Total Pedido 4 (Nuevos Modelos): ${total_pedido_4:.2f}")
    st.write(f"Inventario Promedio: ${inventario_promedio:.2f}")
    st.write(f"KPI de Rotación de Nuevos Modelos: {rotacion_nuevos_modelos:.2f}")

    try:
        # Intentamos abrir el archivo en modo lectura con una codificación diferente
        with open('C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/Moises.txt', 'r',
                  encoding='latin1') as archivo:
            contenido = archivo.read()  # Leemos el contenido del archivo
        st.write(contenido)  # Mostramos el contenido en Streamlit
    except FileNotFoundError:
        st.write("El archivo no se encontró.")  # Si el archivo no existe, mostramos un mensaje de error
    except Exception as e:
        st.write(f"Ocurrió un error: {e}")


# Ejecutar la función para que Streamlit la muestre
moises_junto()
