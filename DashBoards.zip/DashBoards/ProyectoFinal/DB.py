import streamlit as st
pages = {
    "": [st.Page("inicio.py", title="Inicio")],
    "kpi's:": [
        st.Page("page1.py", title="Mejora de Conversión Web" ),
        st.Page("page2.py", title="Mejora en Publicidad"),
        st.Page("page3.py", title="Crecimiento Digital"),
        st.Page("page4.py", title="Optimización Publicitaria")
        ],
    "SMART:": [st.Page("ObjSmart.py", title="Objetivo ")]
}
pg = st.navigation(pages)
pg.run()
